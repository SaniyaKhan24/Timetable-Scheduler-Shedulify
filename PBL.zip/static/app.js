const API_BASE = 'http://localhost:5000/api';

console.log('🚀 App.js loaded');

// ===== DATA STORAGE =====
let timetables = JSON.parse(localStorage.getItem('timetables')) || [];
let divisions = JSON.parse(localStorage.getItem('divisions')) || [];
let subjects = JSON.parse(localStorage.getItem('subjects')) || [];
let faculty = JSON.parse(localStorage.getItem('faculty')) || [];
let rooms = JSON.parse(localStorage.getItem('rooms')) || [];
let timeslots = JSON.parse(localStorage.getItem('timeslots')) || [];

// Track current editing item
let currentEditType = null;
let currentEditIndex = null;

// Add after other global variables
let resourceTracker = null;

// ===== UTILITY FUNCTIONS =====
async function apiGet(path) {
    console.log(`📤 GET ${API_BASE}${path}`);
    try {
        const res = await fetch(`${API_BASE}${path}`);
        const data = await res.json();
        console.log(`📥 Response:`, data);
        return data;
    } catch (error) {
        console.error(`❌ GET Error:`, error);
        throw error;
    }
}

async function apiPost(path, body) {
    console.log(`📤 POST ${API_BASE}${path}`, body);
    try {
        const res = await fetch(`${API_BASE}${path}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        });
        const data = await res.json();
        console.log(`📥 Response:`, data);
        return data;
    } catch (error) {
        console.error(`❌ POST Error:`, error);
        throw error;
    }
}

// ===== HEADER/FOOTER LOADER =====
async function loadHeaderFooter() {
    console.log('Loading header/footer...');
    
    // Inline header HTML as fallback
    const headerHTML = `
        <nav class="site-header navbar" role="navigation" aria-label="Main navigation">
            <div class="nav-container">
                <!-- Left: Logo and Name -->
                <div class="logo" id="logo-link" aria-label="Home" style="cursor: pointer;">
                    <span class="logo-icon"><i class="fas fa-calendar-alt"></i></span>
                    <span class="logo-text">Schedulify</span>
                </div>

                <!-- Center: Main Navigation -->
                <ul class="nav-links nav-center" role="menubar">
                    <li role="none"><a role="menuitem" class="nav-link" href="index.html">Home</a></li>
                    <li role="none"><a role="menuitem" class="nav-link" href="index.html#features">Features</a></li>
                    <li role="none"><a role="menuitem" class="nav-link" href="index.html#how-it-works">How It Works</a></li>
                </ul>

                <!-- Right: Dashboard Button -->
                <div class="nav-right">
                    <a href="dashboard.html" class="btn btn-nav"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </div>
            </div>
        </nav>
    `;

    const footerHTML = `
        <footer class="site-footer">
            <p>&copy; 2024 Schedulify. All rights reserved.</p>
        </footer>
    `;

    try {
        // Try to load from external files first
        const [hdrResp, ftrResp] = await Promise.all([
            fetch('./components/header.html').catch(() => null),
            fetch('./components/footer.html').catch(() => null)
        ]);
        
        const holder = document.getElementById('site-header');
        if (holder) {
            if (hdrResp && hdrResp.ok) {
                const headerText = await hdrResp.text();
                holder.innerHTML = headerText;
                console.log('✅ Header loaded from file');
            } else {
                // Use inline HTML as fallback
                holder.innerHTML = headerHTML;
                console.log('✅ Header loaded from inline HTML');
            }
        }
        
        const fHolder = document.getElementById('site-footer');
        if (fHolder) {
            if (ftrResp && ftrResp.ok) {
                const footerText = await ftrResp.text();
                fHolder.innerHTML = footerText;
                console.log('✅ Footer loaded from file');
            } else {
                // Use inline HTML as fallback
                fHolder.innerHTML = footerHTML;
                console.log('✅ Footer loaded from inline HTML');
            }
        }
        
        // Add logo click handler
        const logo = document.getElementById('logo-link');
        if (logo) {
            logo.addEventListener('click', () => {
                window.location.href = 'index.html';
            });
        }
        
        // Highlight active nav link
        const path = window.location.pathname.split('/').pop() || 'index.html';
        document.querySelectorAll('.site-header .nav-link').forEach(a => {
            const href = a.getAttribute('href') || '';
            if (href.includes(path) || href.split('#')[0] === path) {
                a.classList.add('active');
            }
        });
    } catch (err) {
        console.warn('⚠️ Header/footer load failed, using inline HTML:', err);
        // Fallback to inline HTML
        const holder = document.getElementById('site-header');
        if (holder) holder.innerHTML = headerHTML;
        
        const fHolder = document.getElementById('site-footer');
        if (fHolder) fHolder.innerHTML = footerHTML;
    }
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    loadHeaderFooter(); // Use loadHeaderFooter instead of loadHeader
    initializeTabs();
    renderAllData();
});

// ===== TAB NAVIGATION =====
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-nav-btn');
    const tabPages = document.querySelectorAll('.tab-page');
    
    console.log('Initializing tabs:', tabButtons.length, 'buttons found');
    
    // Ensure only the first tab is active on load
    tabPages.forEach((page, index) => {
        if (index === 0) {
            page.classList.add('active');
            page.style.display = 'block';
        } else {
            page.classList.remove('active');
            page.style.display = 'none';
        }
    });
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            console.log('Tab clicked:', targetPage);
            
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Hide all tab pages
            tabPages.forEach(page => {
                page.classList.remove('active');
                page.style.display = 'none';
            });
            
            // Show target page
            const targetElement = document.getElementById(`${targetPage}-page`);
            if (targetElement) {
                targetElement.classList.add('active');
                targetElement.style.display = 'block';
                console.log('Switched to page:', targetPage);
            } else {
                console.error('Page not found:', `${targetPage}-page`);
            }
        });
    });
}

// ===== RENDER ALL DATA =====
function renderAllData() {
    renderTimetables();
    renderDivisions();
    renderSubjects();
    renderFaculty();
    renderRooms();
    renderTimeslots();
}

// ===== RENDER TIMETABLES =====
function renderTimetables() {
    const container = document.querySelector('.timetables-grid');
    if (!container) return;
    
    if (timetables.length === 0) {
        container.innerHTML = '';
        return;
    }
    
    container.innerHTML = timetables.map(tt => `
        <div class="timetable-card">
            <div class="card-header">
                <div class="card-icon">📅</div>
                <button class="card-delete" onclick="deleteItem('timetables', ${tt.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <h3>${tt.name}</h3>
            <span class="card-status ${tt.status}">${tt.status}</span>
            <div class="card-info">
                <p><i class="fas fa-trophy"></i> Fitness Score: <span class="score">${tt.fitness}%</span></p>
                <p><i class="fas fa-calendar"></i> Created: <span class="date">${new Date(tt.createdAt).toLocaleDateString()}</span></p>
            </div>
            <button class="btn-view" onclick="viewTimetable(${tt.id})">
                <i class="fas fa-eye"></i> View Details
            </button>
        </div>
    `).join('');
}

// ===== RENDER DIVISIONS =====
function renderDivisions() {
    const container = document.getElementById('divisions-list');
    if (!container) return;
    
    if (divisions.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.6);">No divisions added yet. Click "Add Division" to create one.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-layer-group"></i> Division Name</th>
                    <th><i class="fas fa-graduation-cap"></i> Year</th>
                    <th><i class="fas fa-users"></i> Students</th>
                    <th><i class="fas fa-book"></i> Subjects</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                ${divisions.map((division, index) => `
                    <tr>
                        <td><strong>${escapeHtml(division.name)}</strong></td>
                        <td>${division.year}</td>
                        <td>${division.studentCount}</td>
                        <td>${division.subjects?.length || 0} assigned</td>
                        <td>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" onclick="editItem('divisions', ${index})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem;" onclick="deleteItem('divisions', ${division.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ===== RENDER SUBJECTS =====
function renderSubjects() {
    const container = document.getElementById('subjects-list');
    if (!container) return;
    
    if (subjects.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.6);">No subjects added yet. Click "Add Subject" to create one.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-code"></i> Code</th>
                    <th><i class="fas fa-book"></i> Name</th>
                    <th><i class="fas fa-clock"></i> Hours/Week</th>
                    <th><i class="fas fa-layer-group"></i> Type</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                ${subjects.map((subject, index) => `
                    <tr>
                        <td><strong>${escapeHtml(subject.code)}</strong></td>
                        <td>${escapeHtml(subject.name)}</td>
                        <td>${subject.hours}</td>
                        <td><span style="text-transform: capitalize;">${subject.type}</span></td>
                        <td>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" onclick="editItem('subjects', ${index})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem;" onclick="deleteItem('subjects', ${subject.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ===== RENDER FACULTY =====
function renderFaculty() {
    const container = document.getElementById('faculty-list');
    if (!container) return;
    
    if (faculty.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.6);">No faculty members added yet. Click "Add Faculty" to create one.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-user"></i> Name</th>
                    <th><i class="fas fa-id-badge"></i> Employee ID</th>
                    <th><i class="fas fa-graduation-cap"></i> Department</th>
                    <th><i class="fas fa-envelope"></i> Email</th>
                    <th><i class="fas fa-book"></i> Subjects</th>
                    <th><i class="fas fa-layer-group"></i> Divisions</th>
                    <th><i class="fas fa-graduation-cap"></i> Year</th>
                    <th><i class="fas fa-clock"></i> Max Hours</th>
                    <th><i class="fas fa-calendar"></i> Availability</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                ${faculty.map((member, index) => {
                    // Get subject names
                    const subjectNames = member.subjects?.map(subId => {
                        const subject = subjects.find(s => s.id === subId);
                        return subject ? subject.name : 'Unknown';
                    }) || [];
                    
                    // Get division names
                    const divisionNames = member.divisions?.map(divId => {
                        const division = divisions.find(d => d.id === divId);
                        return division ? division.name : 'Unknown';
                    }) || [];
                    
                    // Get year name
                    const yearNames = {
                        '1': 'First Year',
                        '2': 'Second Year',
                        '3': 'Third Year',
                        '4': 'Fourth Year'
                    };
                    const yearName = yearNames[member.year] || 'Not assigned';
                    
                    return `
                        <tr>
                            <td><strong>${escapeHtml(member.name)}</strong></td>
                            <td>${escapeHtml(member.employeeId)}</td>
                            <td>${escapeHtml(member.department)}</td>
                            <td><small>${escapeHtml(member.email || 'N/A')}</small></td>
                            <td>
                                ${subjectNames.length > 0 
                                    ? subjectNames.map(name => `<span style="display: inline-block; background: rgba(255,255,255,0.15); padding: 0.2rem 0.5rem; border-radius: 0.3rem; margin: 0.1rem; font-size: 0.85rem;">${escapeHtml(name)}</span>`).join('')
                                    : '<small style="color: rgba(255,255,255,0.5);">None</small>'
                                }
                            </td>
                            <td>
                                ${divisionNames.length > 0 
                                    ? divisionNames.map(name => `<span style="display: inline-block; background: rgba(168,85,247,0.2); padding: 0.2rem 0.5rem; border-radius: 0.3rem; margin: 0.1rem; font-size: 0.85rem;">${escapeHtml(name)}</span>`).join('')
                                    : '<small style="color: rgba(255,255,255,0.5);">None</small>'
                                }
                            </td>
                            <td><strong>${yearName}</strong></td>
                            <td>${member.maxHours}/week</td>
                            <td>
                                <small style="display: block; margin-bottom: 0.25rem;">
                                    <strong>Days:</strong> ${member.availableDays?.length || 0} days
                                </small>
                                <small style="display: block;">
                                    <strong>Slots:</strong> ${member.availableTimeSlots?.length || 0} slots
                                </small>
                            </td>
                            <td>
                                <button class="btn btn-secondary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" onclick="editItem('faculty', ${index})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-secondary" style="padding: 0.5rem 1rem;" onclick="deleteItem('faculty', ${member.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
}

// ===== RENDER ROOMS =====
function renderRooms() {
    const container = document.getElementById('rooms-list');
    if (!container) return;
    
    if (rooms.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.6);">No rooms added yet. Click "Add Room" to create one.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-door-open"></i> Room</th>
                    <th><i class="fas fa-building"></i> Building</th>
                    <th><i class="fas fa-users"></i> Capacity</th>
                    <th><i class="fas fa-layer-group"></i> Type</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                ${rooms.map((room, index) => `
                    <tr>
                        <td><strong>${escapeHtml(room.number)}</strong></td>
                        <td>${escapeHtml(room.building)}</td>
                        <td>${room.capacity}</td>
                        <td style="text-transform: capitalize;">${room.type}</td>
                        <td>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" onclick="editItem('rooms', ${index})">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-secondary" style="padding: 0.5rem 1rem;" onclick="deleteItem('rooms', ${room.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ===== RENDER TIMESLOTS =====
function renderTimeslots() {
    const container = document.getElementById('timeslots-list');
    if (!container) return;
    
    if (timeslots.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.6);">No time slots added yet. Click "Add Time Slot" to create one.</p>';
        return;
    }
    
    container.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-calendar-day"></i> Day</th>
                    <th><i class="fas fa-clock"></i> Start Time</th>
                    <th><i class="fas fa-clock"></i> End Time</th>
                    <th><i class="fas fa-hourglass-half"></i> Total Hours</th>
                    <th><i class="fas fa-info-circle"></i> Description</th>
                    <th><i class="fas fa-cog"></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                ${timeslots.map((slot, index) => {
                    const hours = calculateHoursDifference(slot.startTime, slot.endTime);
                    return `
                        <tr>
                            <td><strong>${slot.day}</strong></td>
                            <td>${formatTime(slot.startTime)}</td>
                            <td>${formatTime(slot.endTime)}</td>
                            <td><strong>${hours} hours</strong></td>
                            <td>${slot.description || 'Regular class hours'}</td>
                            <td>
                                <button class="btn btn-secondary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;" onclick="editItem('timeslots', ${index})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-secondary" style="padding: 0.5rem 1rem;" onclick="deleteItem('timeslots', ${slot.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
}

// Helper function to calculate hours difference
function calculateHoursDifference(startTime, endTime) {
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    const diffMinutes = endMinutes - startMinutes;
    return (diffMinutes / 60).toFixed(1);
}

// Helper function to format time
function formatTime(time) {
    const [hour, min] = time.split(':');
    const h = parseInt(hour);
    const period = h >= 12 ? 'PM' : 'AM';
    const displayHour = h > 12 ? h - 12 : (h === 0 ? 12 : h);
    return `${displayHour}:${min} ${period}`;
}

// ===== UTILITY FUNCTION =====
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// ===== MODAL FUNCTIONS =====
function toggleForm(type) {
    openModal(type, null);
}

function openModal(type, item = null) {
    const modal = document.getElementById('modal-overlay');
    const modalTitle = document.getElementById('modal-title');
    const modalDescription = document.getElementById('modal-description');
    const modalFormFields = document.getElementById('modal-form-fields');
    const submitBtn = document.getElementById('modal-submit-btn');
    
    const isEdit = item !== null;
    
    // Store current edit info
    currentEditType = type;
    currentEditIndex = isEdit ? getItemIndex(type, item) : null;
    
    // Set modal title and description
    const titles = {
        subjects: isEdit ? 'Edit Subject' : 'Add New Subject',
        faculty: isEdit ? 'Edit Faculty' : 'Add New Faculty',
        rooms: isEdit ? 'Edit Room' : 'Add New Room',
        timeslots: isEdit ? 'Edit Time Slot' : 'Add New Time Slot',
        divisions: isEdit ? 'Edit Division' : 'Add New Division'
    };
    
    const descriptions = {
        subjects: 'Manage course subject information',
        faculty: 'Manage faculty member details',
        rooms: 'Manage classroom information',
        timeslots: 'Define class scheduling time slots',
        divisions: 'Manage student division information'
    };
    
    modalTitle.textContent = titles[type];
    modalDescription.textContent = descriptions[type];
    submitBtn.innerHTML = `<i class="fas fa-${isEdit ? 'save' : 'check'}"></i> ${isEdit ? 'Update' : 'Create'} Item`;
    
    // Generate form fields
    modalFormFields.innerHTML = generateFormFields(type, item);
    
    // Handle form submission
    const form = document.getElementById('modal-form');
    form.onsubmit = (e) => {
        e.preventDefault();
        saveModalForm(type, item);
    };
    
    modal.classList.add('active');
}

function getItemIndex(type, item) {
    const arrays = { subjects, faculty, rooms, timeslots, divisions };
    return arrays[type]?.indexOf(item) ?? -1;
}

function closeModal() {
    const modal = document.getElementById('modal-overlay');
    const modalContainer = modal.querySelector('.modal-container');
    modal.classList.remove('active', 'fullscreen-modal');
    modalContainer.classList.remove('fullscreen-modal');
    document.getElementById('modal-form').reset();
}

function generateFormFields(type, item = null) {
    const forms = {
        divisions: `
            <div class="form-group">
                <label><i class="fas fa-layer-group"></i> Division Name</label>
                <input type="text" id="division-name" value="${item?.name || ''}" placeholder="e.g., A, B, C" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-graduation-cap"></i> Year/Semester</label>
                <select id="division-year" required>
                    <option value="1" ${item?.year === '1' ? 'selected' : ''}>First Year</option>
                    <option value="2" ${item?.year === '2' ? 'selected' : ''}>Second Year</option>
                    <option value="3" ${item?.year === '3' ? 'selected' : ''}>Third Year</option>
                    <option value="4" ${item?.year === '4' ? 'selected' : ''}>Fourth Year</option>
                </select>
            </div>
            <div class="form-group">
                <label><i class="fas fa-users"></i> Number of Students</label>
                <input type="number" id="division-students" value="${item?.studentCount || 60}" min="1" max="200" required>
                <small>Total students in this division</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-book"></i> Assign Subjects</label>
                <select id="division-subjects" multiple style="min-height: 120px;">
                    ${subjects.map(subject => `
                        <option value="${subject.id}" ${item?.subjects?.includes(subject.id) ? 'selected' : ''}>
                            ${subject.code} - ${subject.name}
                        </option>
                    `).join('')}
                </select>
                <small>Hold Ctrl/Cmd to select multiple subjects</small>
            </div>
        `,
        subjects: `
            <div class="form-group">
                <label><i class="fas fa-book"></i> Subject Code</label>
                <input type="text" id="subject-code" value="${item?.code || ''}" placeholder="e.g., CS101" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-heading"></i> Subject Name</label>
                <input type="text" id="subject-name" value="${item?.name || ''}" placeholder="e.g., Data Structures" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-clock"></i> Hours per Week</label>
                <input type="number" id="subject-hours" value="${item?.hours || 3}" min="1" max="10" required>
                <small>Number of class hours per week</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-layer-group"></i> Type</label>
                <select id="subject-type" required>
                    <option value="theory" ${item?.type === 'theory' ? 'selected' : ''}>Theory</option>
                    <option value="lab" ${item?.type === 'lab' ? 'selected' : ''}>Lab</option>
                    <option value="practical" ${item?.type === 'practical' ? 'selected' : ''}>Practical</option>
                </select>
            </div>
        `,
        faculty: `
            <div class="form-group">
                <label><i class="fas fa-user"></i> Faculty Name</label>
                <input type="text" id="faculty-name" value="${item?.name || ''}" placeholder="e.g., Ass. Prof. Gitanjali Yadav" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-id-badge"></i> Employee ID</label>
                <input type="text" id="faculty-id" value="${item?.employeeId || ''}" placeholder="e.g., FAC001" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-graduation-cap"></i> Department</label>
                <input type="text" id="faculty-dept" value="${item?.department || ''}" placeholder="e.g., Computer Science" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" id="faculty-email" value="${item?.email || ''}" placeholder="e.g., gitanjali.yadav@university.edu">
            </div>
            <div class="form-group">
                <label><i class="fas fa-clock"></i> Max Hours per Week</label>
                <input type="number" id="faculty-hours" value="${item?.maxHours || 20}" min="1" max="40" required>
                <small>Maximum teaching hours per week</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-calendar-check"></i> Available Days</label>
                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem;">
                    ${['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => `
                        <label style="display: flex; align-items: center; gap: 0.25rem; background: rgba(255,255,255,0.1); padding: 0.5rem 0.75rem; border-radius: 0.5rem; cursor: pointer;">
                            <input type="checkbox" id="faculty-day-${day}" value="${day}" 
                                ${item?.availableDays?.includes(day) ? 'checked' : ''} 
                                style="cursor: pointer;">
                            <span>${day.substring(0, 3)}</span>
                        </label>
                    `).join('')}
                </div>
                <small>Select days when faculty is available</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-clock"></i> Available Time Slots</label>
                <div style="max-height: 200px; overflow-y: auto; background: rgba(255,255,255,0.05); padding: 0.75rem; border-radius: 0.5rem; border: 1px solid rgba(255,255,255,0.2);">
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 0.5rem;">
                        ${generateTimeSlotOptions(item?.availableTimeSlots || [])}
                    </div>
                </div>
                <small>Select available time slots (8:00 AM - 6:00 PM)</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-book"></i> Assign Subjects</label>
                <select id="faculty-subjects" multiple style="min-height: 120px;">
                    ${subjects.map(subject => `
                        <option value="${subject.id}" ${item?.subjects?.includes(subject.id) ? 'selected' : ''}>
                            ${subject.code} - ${subject.name}
                        </option>
                    `).join('')}
                </select>
                <small>Hold Ctrl/Cmd to select multiple subjects</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-layer-group"></i> Assign Divisions</label>
                <select id="faculty-divisions" multiple style="min-height: 120px;">
                    ${divisions.map(division => `
                        <option value="${division.id}" ${item?.divisions?.includes(division.id) ? 'selected' : ''}>
                            ${division.name} - ${division.year}
                        </option>
                    `).join('')}
                </select>
                <small>Hold Ctrl/Cmd to select multiple divisions</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-graduation-cap"></i> Assign Year</label>
                <select id="faculty-year" required>
                    <option value="1" ${item?.year === '1' ? 'selected' : ''}>First Year</option>
                    <option value="2" ${item?.year === '2' ? 'selected' : ''}>Second Year</option>
                    <option value="3" ${item?.year === '3' ? 'selected' : ''}>Third Year</option>
                    <option value="4" ${item?.year === '4' ? 'selected' : ''}>Fourth Year</option>
                </select>
            </div>
        `,
        rooms: `
            <div class="form-group">
                <label><i class="fas fa-door-open"></i> Room Number</label>
                <input type="text" id="room-number" value="${item?.number || ''}" placeholder="e.g., 201" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-building"></i> Building</label>
                <input type="text" id="room-building" value="${item?.building || ''}" placeholder="e.g., Main Block" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-users"></i> Capacity</label>
                <input type="number" id="room-capacity" value="${item?.capacity || 30}" min="1" max="500" required>
                <small>Maximum number of students</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-layer-group"></i> Room Type</label>
                <select id="room-type" required>
                    <option value="classroom" ${item?.type === 'classroom' ? 'selected' : ''}>Classroom</option>
                    <option value="lab" ${item?.type === 'lab' ? 'selected' : ''}>Lab</option>
                    <option value="auditorium" ${item?.type === 'auditorium' ? 'selected' : ''}>Auditorium</option>
                </select>
            </div>
            <div class="form-group">
                <label><i class="fas fa-check-circle"></i> Facilities</label>
                <input type="text" id="room-facilities" value="${item?.facilities || ''}" placeholder="e.g., Projector, AC, Whiteboard">
                <small>Comma-separated list</small>
            </div>
        `,
        timeslots: `
            <div class="form-group">
                <label><i class="fas fa-calendar-day"></i> Day</label>
                <select id="slot-day" required>
                    <option value="">Select a day</option>
                    <option value="Monday" ${item?.day === 'Monday' ? 'selected' : ''}>Monday</option>
                    <option value="Tuesday" ${item?.day === 'Tuesday' ? 'selected' : ''}>Tuesday</option>
                    <option value="Wednesday" ${item?.day === 'Wednesday' ? 'selected' : ''}>Wednesday</option>
                    <option value="Thursday" ${item?.day === 'Thursday' ? 'selected' : ''}>Thursday</option>
                    <option value="Friday" ${item?.day === 'Friday' ? 'selected' : ''}>Friday</option>
                    <option value="Saturday" ${item?.day === 'Saturday' ? 'selected' : ''}>Saturday</option>
                </select>
                <small>Select the day for this time slot</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-clock"></i> Start Time</label>
                <input type="time" id="slot-start" value="${item?.startTime || '08:00'}" required>
                <small>e.g., 8:00 AM</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-clock"></i> End Time</label>
                <input type="time" id="slot-end" value="${item?.endTime || '15:00'}" required>
                <small>e.g., 3:00 PM (7 hours recommended)</small>
            </div>
            <div class="form-group">
                <label><i class="fas fa-info-circle"></i> Description (Optional)</label>
                <input type="text" id="slot-description" value="${item?.description || ''}" placeholder="e.g., Regular class hours, Morning shift">
                <small>Brief description of this time slot</small>
            </div>
            <div class="form-group">
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 0.5rem; border-left: 3px solid #a855f7;">
                    <p style="margin: 0; font-size: 0.9rem; color: rgba(255,255,255,0.9);">
                        <i class="fas fa-lightbulb" style="color: #fbbf24;"></i> 
                        <strong>Tip:</strong> For a 7-hour day, select:
                    </p>
                    <ul style="margin: 0.5rem 0 0 1.5rem; font-size: 0.85rem; color: rgba(255,255,255,0.8);">
                        <li>8:00 AM to 3:00 PM (with 1 hour lunch break)</li>
                        <li>9:00 AM to 4:00 PM (with 1 hour lunch break)</li>
                        <li>Or customize as per your schedule</li>
                    </ul>
                </div>
            </div>
        `
    };
    
    return forms[type] || '';
}

function generateTimeSlotOptions(selectedSlots = []) {
    const timeSlots = [
        { start: '08:00', end: '09:00', label: '8:00 AM - 9:00 AM' },
        { start: '09:00', end: '10:00', label: '9:00 AM - 10:00 AM' },
        { start: '10:00', end: '11:00', label: '10:00 AM - 11:00 AM' },
        { start: '11:00', end: '12:00', label: '11:00 AM - 12:00 PM' },
        { start: '12:00', end: '13:00', label: '12:00 PM - 1:00 PM' },
        { start: '13:00', end: '14:00', label: '1:00 PM - 2:00 PM' },
        { start: '14:00', end: '15:00', label: '2:00 PM - 3:00 PM' },
        { start: '15:00', end: '16:00', label: '3:00 PM - 4:00 PM' },
        { start: '16:00', end: '17:00', label: '4:00 PM - 5:00 PM' },
        { start: '17:00', end: '18:00', label: '5:00 PM - 6:00 PM' }
    ];
    
    return timeSlots.map((slot, index) => {
        const slotValue = `${slot.start}-${slot.end}`;
        const isChecked = selectedSlots.includes(slotValue);
        
        return `
            <label style="display: flex; align-items: center; gap: 0.5rem; background: rgba(255,255,255,0.1); padding: 0.5rem; border-radius: 0.5rem; cursor: pointer; font-size: 0.9rem;">
                <input type="checkbox" 
                    class="faculty-timeslot" 
                    value="${slotValue}" 
                    ${isChecked ? 'checked' : ''}
                    style="cursor: pointer;">
                <span>${slot.label}</span>
            </label>
        `;
    }).join('');
}

// ===== EDIT ITEM =====
function editItem(type, index) {
    const items = {
        subjects: subjects[index],
        faculty: faculty[index],
        rooms: rooms[index],
        timeslots: timeslots[index],
        divisions: divisions[index]
    };
    
    openModal(type, items[type]);
}

// ===== SAVE MODAL FORM =====
function saveModalForm(type, existingItem) {
    console.log('Saving form for type:', type);
    
    const savers = {
        subjects: () => {
            const newItem = {
                id: existingItem?.id || Date.now(),
                code: document.getElementById('subject-code').value,
                name: document.getElementById('subject-name').value,
                hours: parseInt(document.getElementById('subject-hours').value),
                type: document.getElementById('subject-type').value
            };
            
            if (existingItem) {
                const index = subjects.findIndex(s => s.id === existingItem.id);
                subjects[index] = newItem;
            } else {
                subjects.push(newItem);
            }
            
            localStorage.setItem('subjects', JSON.stringify(subjects));
            renderSubjects();
        },
        
        faculty: () => {
            // Get selected days
            const availableDays = [];
            ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].forEach(day => {
                const checkbox = document.getElementById(`faculty-day-${day}`);
                if (checkbox && checkbox.checked) {
                    availableDays.push(day);
                }
            });
            
            // Get selected time slots
            const availableTimeSlots = [];
            document.querySelectorAll('.faculty-timeslot:checked').forEach(checkbox => {
                availableTimeSlots.push(checkbox.value);
            });
            
            // Get selected subjects
            const selectedSubjects = Array.from(document.getElementById('faculty-subjects').selectedOptions)
                .map(option => parseInt(option.value));
            
            // Get selected divisions
            const selectedDivisions = Array.from(document.getElementById('faculty-divisions').selectedOptions)
                .map(option => parseInt(option.value));
            
            const newItem = {
                id: existingItem?.id || Date.now(),
                name: document.getElementById('faculty-name').value,
                employeeId: document.getElementById('faculty-id').value,
                department: document.getElementById('faculty-dept').value,
                email: document.getElementById('faculty-email').value,
                maxHours: parseInt(document.getElementById('faculty-hours').value),
                availableDays,
                availableTimeSlots,
                subjects: selectedSubjects,
                divisions: selectedDivisions,
                year: document.getElementById('faculty-year').value
            };
            
            if (existingItem) {
                const index = faculty.findIndex(f => f.id === existingItem.id);
                faculty[index] = newItem;
            } else {
                faculty.push(newItem);
            }
            
            localStorage.setItem('faculty', JSON.stringify(faculty));
            renderFaculty();
        },
        
        rooms: () => {
            const newItem = {
                id: existingItem?.id || Date.now(),
                number: document.getElementById('room-number').value,
                building: document.getElementById('room-building').value,
                capacity: parseInt(document.getElementById('room-capacity').value),
                type: document.getElementById('room-type').value,
                facilities: document.getElementById('room-facilities').value
            };
            
            if (existingItem) {
                const index = rooms.findIndex(r => r.id === existingItem.id);
                rooms[index] = newItem;
            } else {
                rooms.push(newItem);
            }
            
            localStorage.setItem('rooms', JSON.stringify(rooms));
            renderRooms();
        },
        
        timeslots: () => {
            const newItem = {
                id: existingItem?.id || Date.now(),
                day: document.getElementById('slot-day').value,
                startTime: document.getElementById('slot-start').value,
                endTime: document.getElementById('slot-end').value,
                description: document.getElementById('slot-description').value
            };
            
            if (existingItem) {
                const index = timeslots.findIndex(t => t.id === existingItem.id);
                timeslots[index] = newItem;
            } else {
                timeslots.push(newItem);
            }
            
            localStorage.setItem('timeslots', JSON.stringify(timeslots));
            renderTimeslots();
        },
        
        divisions: () => {
            const selectedSubjects = Array.from(document.getElementById('division-subjects').selectedOptions)
                .map(option => parseInt(option.value));
            
            const newItem = {
                id: existingItem?.id || Date.now(),
                name: document.getElementById('division-name').value,
                year: document.getElementById('division-year').value,
                studentCount: parseInt(document.getElementById('division-students').value),
                subjects: selectedSubjects
            };
            
            if (existingItem) {
                const index = divisions.findIndex(d => d.id === existingItem.id);
                divisions[index] = newItem;
            } else {
                divisions.push(newItem);
            }
            
            localStorage.setItem('divisions', JSON.stringify(divisions));
            renderDivisions();
        }
    };
    
    if (savers[type]) {
        savers[type]();
        closeModal();
        console.log(`${type} saved successfully`);
    }
}

// ===== DELETE FUNCTIONS =====
function deleteItem(type, id) {
    if (!confirm('Are you sure you want to delete this item?')) return;
    
    const deleters = {
        divisions: () => {
            divisions = divisions.filter(d => d.id !== id);
            localStorage.setItem('divisions', JSON.stringify(divisions));
            renderDivisions();
        },
        subjects: () => {
            subjects = subjects.filter(s => s.id !== id);
            localStorage.setItem('subjects', JSON.stringify(subjects));
            renderSubjects();
        },
        faculty: () => {
            faculty = faculty.filter(f => f.id !== id);
            localStorage.setItem('faculty', JSON.stringify(faculty));
            renderFaculty();
        },
        rooms: () => {
            rooms = rooms.filter(r => r.id !== id);
            localStorage.setItem('rooms', JSON.stringify(rooms));
            renderRooms();
        },
        timeslots: () => {
            timeslots = timeslots.filter(t => t.id !== id);
            localStorage.setItem('timeslots', JSON.stringify(timeslots));
            renderTimeslots();
        },
        timetables: () => {
            timetables = timetables.filter(t => t.id !== id);
            localStorage.setItem('timetables', JSON.stringify(timetables));
            renderTimetables();
        }
    };
    
    if (deleters[type]) {
        deleters[type]();
        console.log(`${type} item deleted successfully`);
    }
}

// ===== NAVIGATION FUNCTIONS =====
function navigateToGenerate() {
    console.log('Navigating to generate page');
    
    // Get all tab buttons and pages
    const tabButtons = document.querySelectorAll('.tab-nav-btn');
    const tabPages = document.querySelectorAll('.tab-page');
    
    // Remove active class from all buttons
    tabButtons.forEach(btn => btn.classList.remove('active'));
    
    // Hide all pages
    tabPages.forEach(page => {
        page.classList.remove('active');
        page.style.display = 'none';
    });
    
    // Show generate page
    const generatePage = document.getElementById('generate-page');
    if (generatePage) {
        generatePage.classList.add('active');
        generatePage.style.display = 'block';
        
        // Populate division dropdown
        populateDivisionSelect();
        
        console.log('Generate page activated');
    } else {
        console.error('Generate page not found');
    }
}

function populateDivisionSelect() {
    const divisionSelect = document.getElementById('division-select');
    if (!divisionSelect) return;
    
    // Clear existing options except the first one
    divisionSelect.innerHTML = '<option value="">-- Select a Division --</option>';
    
    if (divisions.length === 0) {
        divisionSelect.innerHTML += '<option value="" disabled>No divisions available</option>';
        return;
    }
    
    // Add divisions with their details
    divisions.forEach(division => {
        const subjectCount = division.subjects?.length || 0;
        const option = document.createElement('option');
        option.value = division.id;
        option.textContent = `${division.name} - Year ${division.year} (${division.studentCount} students, ${subjectCount} subjects)`;
        divisionSelect.appendChild(option);
    });
}

// ===== VIEW TIMETABLE =====
function viewTimetable(id) {
    const timetable = timetables.find(t => t.id === id);
    if (!timetable) {
        alert('Timetable not found!');
        return;
    }
    const modal = document.getElementById('modal-overlay');
    const modalContainer = modal.querySelector('.modal-container');

    // Generate sample schedule if it doesn't exist
    if (!timetable.schedule) {
        timetable.schedule = generateSampleSchedule();
        localStorage.setItem('timetables', JSON.stringify(timetables));
    }

    // Add fullscreen classes
    modal.classList.add('fullscreen-modal');
    modalContainer.classList.add('fullscreen-modal');

    modalContainer.innerHTML = `
        <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
        <div class="modal-header">
            <h2><i class="fas fa-calendar-check"></i> ${timetable.name}</h2>
            <p>Fitness Score: ${timetable.fitness}% | Created: ${new Date(timetable.createdAt).toLocaleDateString()}</p>
        </div>
        <div class="schedule-table">
            ${generateScheduleTable(timetable.schedule)}
        </div>
        <div class="modal-actions">
            <button class="btn-modal_primary" onclick="downloadTimetable(${id})">
                <i class="fas fa-download"></i> Download
            </button>
            <button class="btn-modal_secondary" onclick="printTimetable(${id})">
                <i class="fas fa-print"></i> Print
            </button>
            <button class="btn-modal_secondary" onclick="closeModal()">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    `;
    modal.classList.add('active');
}

// ===== GENERATE SAMPLE SCHEDULE =====
function generateSampleSchedule() {
    if (divisions.length === 0) {
        alert('Please add at least one division before generating timetables.');
        return null;
    }
    
    const allSchedules = [];
    
    divisions.forEach(division => {
        const divisionSchedule = generateDivisionSchedule(division);
        allSchedules.push(...divisionSchedule);
    });
    
    // Check for faculty clashes
    const clashes = checkFacultyClash(allSchedules);
    if (clashes.length > 0) {
        console.warn('Faculty clashes detected:', clashes);
    }
    
    return allSchedules;
}

function generateDivisionSchedule(division) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    
    // Get configured time slots or use default
    const defaultTimeSlots = [
        { start: '08:00', end: '09:00' },
        { start: '09:00', end: '10:00' },
        { start: '10:00', end: '11:00' },
        { start: '11:00', end: '12:00' },
        { start: '12:00', end: '13:00', isBreak: true },
        { start: '13:00', end: '14:00' },
        { start: '14:00', end: '15:00' }
    ];
    
    let timeSlots = [];
    if (timeslots.length > 0) {
        const configuredSlot = timeslots[0];
        timeSlots = generateHourlySlotsFromRange(configuredSlot.startTime, configuredSlot.endTime);
    } else {
        timeSlots = defaultTimeSlots;
    }
    
    const schedule = [];
    const divisionSubjects = subjects.filter(s => division.subjects?.includes(s.id));
    
    if (divisionSubjects.length === 0) {
        console.warn(`No subjects assigned to division ${division.name}`);
        return schedule;
    }
    
    // Get faculty assigned to this division and year
    const availableFacultyForDivision = faculty.filter(f => 
        (f.divisions?.includes(division.id) || f.year === division.year) &&
        f.subjects?.some(subId => divisionSubjects.find(s => s.id === subId))
    );
    
    console.log(`Division ${division.name}: ${divisionSubjects.length} subjects, ${availableFacultyForDivision.length} faculty members`);
    
    days.forEach(day => {
        timeSlots.forEach((slot) => {
            // Lunch break
            if (slot.isBreak || slot.start === '12:00') {
                schedule.push({
                    division: division.name,
                    divisionId: division.id,
                    day,
                    timeSlot: `${slot.start} - ${slot.end}`,
                    subject: 'LUNCH BREAK',
                    faculty: '-',
                    room: '-',
                    type: 'break'
                });
                return;
            }
            
            // Select a random subject from division's subjects
            const subject = divisionSubjects[Math.floor(Math.random() * divisionSubjects.length)];
            
            // Find faculty who can teach this subject and are available on this day
            const eligibleFaculty = availableFacultyForDivision.filter(f => 
                f.subjects?.includes(subject.id) &&
                (f.availableDays?.includes(day) || !f.availableDays || f.availableDays.length === 0)
            );
            
            const facultyMember = eligibleFaculty.length > 0
                ? eligibleFaculty[Math.floor(Math.random() * eligibleFaculty.length)]
                : { name: 'TBA', employeeId: 'N/A', id: null };
            
            // Find suitable room based on subject type and division size
            const suitableRooms = rooms.filter(r => 
                r.capacity >= division.studentCount &&
                (subject.type === 'lab' ? r.type === 'lab' : true)
            );
            
            const room = suitableRooms.length > 0
                ? suitableRooms[Math.floor(Math.random() * suitableRooms.length)]
                : { number: 'TBA', building: 'N/A', type: 'classroom', id: null };
            
            schedule.push({
                division: division.name,
                divisionId: division.id,
                day,
                timeSlot: `${slot.start} - ${slot.end}`,
                subject: `${subject.code} - ${subject.name}`,
                subjectCode: subject.code,
                subjectName: subject.name,
                faculty: facultyMember.name,
                facultyId: facultyMember.id,
                room: `${room.number} (${room.building})`,
                roomId: room.id,
                type: subject.type
            });
        });
    });
    
    return schedule;
}

// ===== FACULTY CLASH DETECTION =====
function checkFacultyClash(schedule) {
    const clashes = [];
    const facultySchedule = {};
    
    schedule.forEach(entry => {
        if (entry.type === 'break') return;
        
        const key = `${entry.faculty}-${entry.day}-${entry.timeSlot}`;
        
        if (facultySchedule[key]) {
            clashes.push({
                faculty: entry.faculty,
                day: entry.day,
                timeSlot: entry.timeSlot,
                divisions: [facultySchedule[key].division, entry.division]
            });
        } else {
            facultySchedule[key] = entry;
        }
    });
    
    return clashes;
}

// Helper function to generate hourly slots from a time range
function generateHourlySlotsFromRange(startTime, endTime) {
    const slots = [];
    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    
    let currentHour = startHour;
    
    while (currentHour < endHour) {
        const start = `${String(currentHour).padStart(2, '0')}:00`;
        const end = `${String(currentHour + 1).padStart(2, '0')}:00`;
        
        // Mark 12:00-13:00 as lunch break
        if (currentHour === 12) {
            slots.push({ start, end, isBreak: true });
        } else {
            slots.push({ start, end });
        }
        
        currentHour++;
    }
    
    return slots;
}

// ===== GENERATE SCHEDULE TABLE =====
function generateScheduleTable(schedule) {
    if (!schedule || schedule.length === 0) {
        return '<p style="text-align: center; padding: 2rem; color: rgba(255,255,255,0.8);">No schedule data available</p>';
    }
    
    // Group by day and division
    const scheduleByDivision = {};
    
    schedule.forEach(entry => {
        if (!scheduleByDivision[entry.division]) {
            scheduleByDivision[entry.division] = {};
        }
        if (!scheduleByDivision[entry.division][entry.day]) {
            scheduleByDivision[entry.division][entry.day] = [];
        }
        scheduleByDivision[entry.division][entry.day].push(entry);
    });
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    let html = '';
    
    // Generate table for each division
    Object.entries(scheduleByDivision).forEach(([divisionName, divisionSchedule]) => {
        // Sort entries by time for each day
        Object.keys(divisionSchedule).forEach(day => {
            divisionSchedule[day].sort((a, b) => {
                const aTime = a.timeSlot.split(' - ')[0];
                const bTime = b.timeSlot.split(' - ')[0];
                return aTime.localeCompare(bTime);
            });
        });
        
        html += `
            <div style="margin-bottom: 3rem;">
                <h3 style="color: white; margin-bottom: 1.5rem; padding: 1rem; background: rgba(168,85,247,0.3); border-radius: 0.75rem; border-left: 4px solid #a855f7;">
                    <i class="fas fa-layer-group"></i> Division ${escapeHtml(divisionName)}
                </h3>
        `;
        
        // Get all unique time slots for this division
        const timeSlots = [...new Set(
            Object.values(divisionSchedule).flat().map(entry => entry.timeSlot)
        )].sort();
        
        // Create weekly view table
        html += `
            <div style="overflow-x: auto; margin-bottom: 2rem;">
                <table style="min-width: 100%; background: rgba(255,255,255,0.08); border-collapse: collapse;">
                    <thead>
                        <tr style="background: rgba(168,85,247,0.4);">
                            <th style="min-width: 120px; position: sticky; left: 0; background: rgba(168,85,247,0.5); z-index: 2; padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">
                                <i class="fas fa-clock"></i> Time
                            </th>
                            ${days.map(day => `
                                <th style="min-width: 200px; padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">
                                    <i class="fas fa-calendar-day"></i> ${day}
                                </th>
                            `).join('')}
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        timeSlots.forEach(timeSlot => {
            html += '<tr>';
            html += `<td style="font-weight: 600; position: sticky; left: 0; background: rgba(168,85,247,0.2); z-index: 1; padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">${timeSlot}</td>`;
            
            days.forEach(day => {
                const entry = divisionSchedule[day]?.find(e => e.timeSlot === timeSlot);
                
                if (!entry) {
                    html += '<td style="background: rgba(255,255,255,0.02); padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">-</td>';
                } else if (entry.type === 'break' || entry.subject === 'LUNCH BREAK') {
                    html += `
                        <td style="background: rgba(251, 191, 36, 0.15); text-align: center; padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">
                            <span style="color: #fbbf24; font-weight: 600;">
                                <i class="fas fa-utensils"></i> LUNCH BREAK
                            </span>
                        </td>
                    `;
                } else {
                    html += `
                        <td style="background: rgba(255,255,255,0.05); padding: 1rem; border: 1px solid rgba(255,255,255,0.1);">
                            <div style="margin-bottom: 0.5rem;">
                                <strong style="color: #a855f7; font-size: 0.95rem;">
                                    <i class="fas fa-book"></i> ${escapeHtml(entry.subjectCode || entry.subject.split(' - ')[0])}
                                </strong>
                            </div>
                            <div style="margin-bottom: 0.3rem; font-size: 0.85rem; color: white;">
                                ${escapeHtml(entry.subjectName || entry.subject.split(' - ')[1] || entry.subject)}
                            </div>
                            <div style="font-size: 0.8rem; color: rgba(255,255,255,0.7); margin-bottom: 0.2rem;">
                                <i class="fas fa-chalkboard-teacher"></i> ${escapeHtml(entry.faculty)}
                            </div>
                            <div style="font-size: 0.8rem; color: rgba(255,255,255,0.6);">
                                <i class="fas fa-door-open"></i> ${escapeHtml(entry.room)}
                            </div>
                        </td>
                    `;
                }
            });
            
            html += '</tr>';
        });
        
        html += `
                    </tbody>
                </table>
            </div>
        </div>
        `;
    });
    
    return html;
}

// ===== DOWNLOAD TIMETABLE =====
function downloadTimetable(id) {
    const timetable = timetables.find(t => t.id === id);
    if (!timetable || !timetable.schedule) {
        alert('No timetable data to download');
        return;
    }
    
    // Convert schedule to CSV
    let csv = 'Division,Day,Time,Subject,Faculty,Room,Type\n';
    timetable.schedule.forEach(entry => {
        csv += `"${entry.division}","${entry.day}","${entry.timeSlot}","${entry.subject}","${entry.faculty}","${entry.room}","${entry.type || 'regular'}"\n`;
    });
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${timetable.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// ===== PRINT TIMETABLE =====
function printTimetable(id) {
    const timetable = timetables.find(t => t.id === id);
    if (!timetable || !timetable.schedule) {
        alert('No timetable data to print');
        return;
    }
    
    // Create print window
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${timetable.name}</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    color: #333;
                }
                h1 {
                    text-align: center;
                    color: #7c3aed;
                    margin-bottom: 10px;
                }
                .info {
                    text-align: center;
                    margin-bottom: 30px;
                    color: #666;
                }
                h3 {
                    color: #7c3aed;
                    margin-top: 30px;
                    padding: 10px;
                    background: #f3f4f6;
                    border-left: 4px solid #7c3aed;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 30px;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 12px;
                    text-align: left;
                }
                th {
                    background-color: #7c3aed;
                    color: white;
                }
                tr:nth-child(even) {
                    background-color: #f9fafb;
                }
                .break {
                    background-color: #fef3c7 !important;
                    font-weight: bold;
                    color: #92400e;
                }
                @media print {
                    .no-print {
                        display: none;
                    }
                }
            </style>
        </head>
        <body>
            <h1>${timetable.name}</h1>
            <div class="info">
                <p>Fitness Score: ${timetable.fitness}% | Created: ${new Date(timetable.createdAt).toLocaleDateString()}</p>
            </div>
            ${generateScheduleTable(timetable.schedule)}
            <button class="no-print" onclick="window.print()" style="display: block; margin: 20px auto; padding: 10px 20px; background: #7c3aed; color: white; border: none; border-radius: 5px; cursor: pointer;">Print</button>
        </body>
        </html>
    `);
    printWindow.document.close();
}