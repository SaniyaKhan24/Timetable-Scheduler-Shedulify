class ResourceTracker {
    constructor() {
        this.facultySchedule = {}; // faculty_id -> {day-time: division_id}
        this.roomSchedule = {};     // room_id -> {day-time: division_id}
        this.facultyHours = {};     // faculty_id -> total_hours
        this.divisionSchedule = {}; // division_id -> [{day, timeSlot, ...}]
    }

    reset() {
        this.facultySchedule = {};
        this.roomSchedule = {};
        this.facultyHours = {};
        this.divisionSchedule = {};
    }

    getTimeKey(day, timeSlot) {
        return `${day}-${timeSlot}`;
    }

    isFacultyAvailable(facultyId, day, timeSlot, facultyData) {
        const timeKey = this.getTimeKey(day, timeSlot);
        const scheduleKey = `${facultyId}-${timeKey}`;

        // Check if already teaching at this time
        if (this.facultySchedule[scheduleKey]) {
            return { available: false, reason: 'Already teaching another class' };
        }

        // Check faculty's available days
        if (facultyData.availableDays && facultyData.availableDays.length > 0) {
            if (!facultyData.availableDays.includes(day)) {
                return { available: false, reason: 'Not available on this day' };
            }
        }

        // Check faculty's available time slots
        if (facultyData.availableTimeSlots && facultyData.availableTimeSlots.length > 0) {
            const slotMatch = facultyData.availableTimeSlots.some(slot => {
                return timeSlot.includes(slot.split('-')[0]);
            });
            if (!slotMatch) {
                return { available: false, reason: 'Not available at this time' };
            }
        }

        // Check weekly hour limit
        const currentHours = this.facultyHours[facultyId] || 0;
        if (currentHours >= facultyData.maxHours) {
            return { available: false, reason: 'Weekly hour limit exceeded' };
        }

        return { available: true };
    }

    isRoomAvailable(roomId, day, timeSlot) {
        const timeKey = this.getTimeKey(day, timeSlot);
        const scheduleKey = `${roomId}-${timeKey}`;

        if (this.roomSchedule[scheduleKey]) {
            return { available: false, reason: 'Room already occupied' };
        }

        return { available: true };
    }

    assignResource(facultyId, roomId, day, timeSlot, divisionId) {
        const timeKey = this.getTimeKey(day, timeSlot);
        
        // Mark faculty as occupied
        this.facultySchedule[`${facultyId}-${timeKey}`] = divisionId;
        
        // Mark room as occupied
        this.roomSchedule[`${roomId}-${timeKey}`] = divisionId;
        
        // Increment faculty hours
        this.facultyHours[facultyId] = (this.facultyHours[facultyId] || 0) + 1;
        
        // Add to division schedule
        if (!this.divisionSchedule[divisionId]) {
            this.divisionSchedule[divisionId] = [];
        }
        this.divisionSchedule[divisionId].push({ day, timeSlot, facultyId, roomId });
    }

    unassignResource(facultyId, roomId, day, timeSlot, divisionId) {
        const timeKey = this.getTimeKey(day, timeSlot);
        
        delete this.facultySchedule[`${facultyId}-${timeKey}`];
        delete this.roomSchedule[`${roomId}-${timeKey}`];
        
        if (this.facultyHours[facultyId]) {
            this.facultyHours[facultyId]--;
        }
        
        if (this.divisionSchedule[divisionId]) {
            this.divisionSchedule[divisionId] = this.divisionSchedule[divisionId].filter(
                entry => !(entry.day === day && entry.timeSlot === timeSlot)
            );
        }
    }

    getConflicts() {
        const conflicts = [];
        
        // Check for faculty double-booking
        Object.entries(this.facultySchedule).forEach(([key, divisionId]) => {
            const [facultyId, timeKey] = key.split('-', 2);
            const [day, timeSlot] = timeKey.split('-');
            
            const sameTimeSlots = Object.entries(this.facultySchedule).filter(
                ([k, d]) => k.includes(timeKey) && k !== key
            );
            
            if (sameTimeSlots.length > 0) {
                conflicts.push({
                    type: 'faculty',
                    facultyId,
                    day,
                    timeSlot,
                    divisions: [divisionId, ...sameTimeSlots.map(([, d]) => d)]
                });
            }
        });

        return conflicts;
    }

    getValidationReport() {
        return {
            facultyWorkload: Object.entries(this.facultyHours).map(([id, hours]) => ({
                facultyId: id,
                assignedHours: hours
            })),
            roomUtilization: Object.keys(this.roomSchedule).length,
            conflicts: this.getConflicts(),
            totalAssignments: Object.keys(this.facultySchedule).length
        };
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ResourceTracker;
}
